package aplimovil.david.mimedico.util;

import java.util.List;

import aplimovil.david.mimedico.models.PacTra;
import aplimovil.david.mimedico.models.Paciente;
import aplimovil.david.mimedico.models.Tratamiento;

/**
 * Created by david on 17/09/2015.
 */
public class AppUtil {
    public static List<Tratamiento> data;
    public static List<Paciente> data1;
    public static List<PacTra> data2;
}
